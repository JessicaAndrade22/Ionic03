/**
 *  Nome: Jéssica de Andrade Oliveira RA: 201515225
 */

export interface Filme {
    nome: string;
    descricao: string;
}

export interface Genero {
    nome: string;
    genero: string;
}